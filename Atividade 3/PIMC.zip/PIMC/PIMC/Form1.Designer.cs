﻿
namespace PIMC
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtWt = new System.Windows.Forms.MaskedTextBox();
            this.txtHt = new System.Windows.Forms.MaskedTextBox();
            this.txtIMC = new System.Windows.Forms.MaskedTextBox();
            this.btCalculate = new System.Windows.Forms.Button();
            this.btCls = new System.Windows.Forms.Button();
            this.btOut = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Narrow", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(35, 68);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(171, 44);
            this.label1.TabIndex = 0;
            this.label1.Text = "Peso Atual";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Narrow", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(35, 167);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(101, 44);
            this.label2.TabIndex = 1;
            this.label2.Text = "Altura";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial Narrow", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(35, 261);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 44);
            this.label3.TabIndex = 2;
            this.label3.Text = "IMC";
            // 
            // txtWt
            // 
            this.txtWt.Location = new System.Drawing.Point(234, 86);
            this.txtWt.Mask = "000,00";
            this.txtWt.Name = "txtWt";
            this.txtWt.Size = new System.Drawing.Size(255, 22);
            this.txtWt.TabIndex = 3;
            this.txtWt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtWt_KeyPress);
            this.txtWt.Validated += new System.EventHandler(this.txtWt_Validated);
            // 
            // txtHt
            // 
            this.txtHt.Location = new System.Drawing.Point(234, 185);
            this.txtHt.Mask = "0,00";
            this.txtHt.Name = "txtHt";
            this.txtHt.Size = new System.Drawing.Size(255, 22);
            this.txtHt.TabIndex = 4;
            this.txtHt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtHt_KeyPress);
            this.txtHt.Validated += new System.EventHandler(this.txtHt_Validated);
            // 
            // txtIMC
            // 
            this.txtIMC.Location = new System.Drawing.Point(234, 279);
            this.txtIMC.Name = "txtIMC";
            this.txtIMC.ReadOnly = true;
            this.txtIMC.Size = new System.Drawing.Size(255, 22);
            this.txtIMC.TabIndex = 5;
            this.txtIMC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtIMC_KeyPress);
            // 
            // btCalculate
            // 
            this.btCalculate.Font = new System.Drawing.Font("Arial Narrow", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btCalculate.Location = new System.Drawing.Point(43, 356);
            this.btCalculate.Name = "btCalculate";
            this.btCalculate.Size = new System.Drawing.Size(163, 85);
            this.btCalculate.TabIndex = 6;
            this.btCalculate.Text = "Calcular";
            this.btCalculate.UseVisualStyleBackColor = true;
            this.btCalculate.Click += new System.EventHandler(this.btCalculate_Click);
            // 
            // btCls
            // 
            this.btCls.Font = new System.Drawing.Font("Arial Narrow", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btCls.Location = new System.Drawing.Point(225, 356);
            this.btCls.Name = "btCls";
            this.btCls.Size = new System.Drawing.Size(163, 85);
            this.btCls.TabIndex = 7;
            this.btCls.Text = "Limpar";
            this.btCls.UseVisualStyleBackColor = true;
            this.btCls.Click += new System.EventHandler(this.btCls_Click);
            // 
            // btOut
            // 
            this.btOut.Font = new System.Drawing.Font("Arial Narrow", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btOut.Location = new System.Drawing.Point(406, 356);
            this.btOut.Name = "btOut";
            this.btOut.Size = new System.Drawing.Size(163, 85);
            this.btOut.TabIndex = 8;
            this.btOut.Text = "Sair";
            this.btOut.UseVisualStyleBackColor = true;
            this.btOut.Click += new System.EventHandler(this.btOut_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(581, 513);
            this.Controls.Add(this.btOut);
            this.Controls.Add(this.btCls);
            this.Controls.Add(this.btCalculate);
            this.Controls.Add(this.txtIMC);
            this.Controls.Add(this.txtHt);
            this.Controls.Add(this.txtWt);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.MaskedTextBox txtWt;
        private System.Windows.Forms.MaskedTextBox txtHt;
        private System.Windows.Forms.MaskedTextBox txtIMC;
        private System.Windows.Forms.Button btCalculate;
        private System.Windows.Forms.Button btCls;
        private System.Windows.Forms.Button btOut;
    }
}

