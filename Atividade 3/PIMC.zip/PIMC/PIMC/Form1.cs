﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PIMC
{
    public partial class Form1 : Form
    {
        double peso, altura, imc;
        public Form1()
        {

            InitializeComponent();
        }

        private void txtWt_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)(13))
            {
                SendKeys.Send("{TAB}");
                e.Handled = true;
            }
        }

        private void txtHt_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)(13))
            {
                SendKeys.Send("{TAB}");
                e.Handled = true;
            }
        }

        private void txtIMC_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)(13))
            {
                SendKeys.Send("{TAB}");
                e.Handled = true;
            }
        }

        private void btCls_Click(object sender, EventArgs e)
        {
            txtWt.Clear();
            txtHt.Clear();
            txtIMC.Clear();
        }

        private void btOut_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btCalculate_Click(object sender, EventArgs e)
        {
            imc = peso / Math.Pow(altura,2);

            txtIMC.Text = imc.ToString("N1");

            if (imc < 18.5)
                MessageBox.Show("Magreza");

            else if (imc <= 24.9)
                MessageBox.Show("Normal");

            else if (imc <= 29.9)
                MessageBox.Show("Sobrepeso");

            else if (imc <=39.9)
                MessageBox.Show("Obesidade");

            else
                MessageBox.Show("Obesidade Grave");
        }

        private void txtWt_Validated(object sender, EventArgs e)
        {
            if (Double.TryParse(txtWt.Text, out peso))
            {
                MessageBox.Show("Digite o peso !");
            }
        }

        private void txtHt_Validated(object sender, EventArgs e)
        {
            if (Double.TryParse(txtHt.Text, out altura))
            {
                MessageBox.Show("Digite a altura !");
            }
        }
    }
}
