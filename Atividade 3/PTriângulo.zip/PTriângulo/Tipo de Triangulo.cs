﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriângulo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btClean_Click(object sender, EventArgs e)
        {
            txtLadoA.Clear();
            txtLadoB.Clear();
            txtLadoC.Clear();
        }

        private void txtLadoA_TextChanged(object sender, EventArgs e)
        {}

        private void txtLadoB_TextChanged(object sender, EventArgs e)
        {}

        private void txtLadoC_TextChanged(object sender, EventArgs e)
        {}

        private void btVerificar_Click(object sender, EventArgs e)
        {
            double ladoA;
            double ladoB;
            double ladoC;

            if (!double.TryParse(txtLadoA.Text, out ladoA))
                MessageBox.Show("Lado A Inválido!");

            else if (!double.TryParse(txtLadoB.Text, out ladoB))
                MessageBox.Show("Lado B Inválido!");

            else if (!double.TryParse(txtLadoC.Text, out ladoC))
                MessageBox.Show("Lado C Inválido!");

            else //testar se forma um triângulo
            { //regra: (|b-c|) < a < (b + c) | (|a - c|) < b < (a + c) | (|a - b|) < c < (a + b)
                if (ladoA < (ladoB + ladoC) && ladoA > Math.Abs(ladoB - ladoC) && ladoB < (ladoA + ladoC) && ladoB > Math.Abs(ladoA - ladoC) && ladoC < (ladoA + ladoB) && ladoC > Math.Abs(ladoA - ladoB))
                {
                    if ((ladoA == ladoB) && (ladoB == ladoC))
                        MessageBox.Show("É um equilátero");

                    else if ((ladoA != ladoB) && (ladoB != ladoC) && (ladoA != ladoC))
                        MessageBox.Show("É um escaleno");

                    else
                        MessageBox.Show("É um isóceles");
                }

                else
                    MessageBox.Show("Lados não formam um Triângulo!");
            }
        }

        private void txtLadoA_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)(13))
            {
                SendKeys.Send("{TAB}");
                e.Handled = true;
            }
        }

        private void txtLadoB_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)(13))
            {
                SendKeys.Send("{TAB}");
                e.Handled = true;
            }
        }

        private void txtLadoC_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)(13))
            {
                SendKeys.Send("{TAB}");
                e.Handled = true;
            }
        }
    }
}
