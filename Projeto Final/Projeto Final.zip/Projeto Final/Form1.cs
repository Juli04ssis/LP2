﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace Projeto_Final
{
    public partial class Form1 : Form
    {
        public static SqlConnection conexao;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                conexao = new SqlConnection("Data Source=LAPTOP-DLE4QAVB;Initial Catalog=LP2;Integrated Security=True;Pooling=False");
                conexao.Open();
            }
            catch (SqlException ex) 
            {
                MessageBox.Show("Erro de banco de dados =/" + ex.Message); 
            }

            catch (Exception ex)
            {
                MessageBox.Show("Outros Erros =/" + ex.Message);
            }
    }

        private void btnCidade_Click(object sender, EventArgs e)
        {
            frmCidade objCidade = new frmCidade();
            objCidade.WindowState = FormWindowState.Normal;
            objCidade.ShowDialog();
        }

        private void contatoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmContato>().Count() > 0)
            {
                MessageBox.Show("Form já existe!");
                Application.OpenForms["frmContato"].BringToFront();
            }
            else
            {
                frmContato objC = new frmContato();
                objC.MdiParent = this;
                objC.WindowState = FormWindowState.Maximized;
                objC.Show();
            }
        }

        private void cidadeToolStripMenuItem_Click(object sender, EventArgs e)
        {            
            if(Application.OpenForms.OfType<frmCidade>().Count()>0)
            {
                MessageBox.Show("Form já existe!");
                Application.OpenForms["frmCidade"].BringToFront();
            }
            else
            {
                frmCidade objC = new frmCidade();
                objC.MdiParent = this;
                objC.WindowState = FormWindowState.Maximized;
                objC.Show();
            }
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void sobreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmSobre objC = new frmSobre();
            objC.Show();
        }
    }
}
