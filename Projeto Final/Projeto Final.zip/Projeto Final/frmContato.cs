﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto_Final
{
    public partial class frmContato : Form
    {
        private BindingSource bnContato = new BindingSource();
        private bool bInclusao = false;
        private DataSet dsContato = new DataSet();
        private DataSet dsCidade = new DataSet();

        public frmContato()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void lblEmail_Click(object sender, EventArgs e)
        {

        }

        private void txtID_TextChanged(object sender, EventArgs e)
        {
            if(txtID.Text == "")
                while(txtID.Text == "")
                    MessageBox.Show("Insira um valor Válido.");
                    
        }

        private void frmContato_Load(object sender, EventArgs e)
        {
            try
            {
                Contato Con = new Contato();
                dsContato.Tables.Add(Con.Listar());
                bnContato.DataSource = dsContato.Tables["Contato"];
                dgvContato.DataSource = bnContato;
                bnvContato.BindingSource = bnContato;

                txtID.DataBindings.Add("TEXT", bnContato, "Id_contato");
                txtNome.DataBindings.Add("TEXT", bnContato, "nome_contato");
                txtEnd.DataBindings.Add("TEXT", bnContato, "end_contato");
                txtCelular.DataBindings.Add("TEXT", bnContato, "cel_contato");
                txtEmail.DataBindings.Add("TEXT", bnContato, "email_contato");
                dtTimePicker.DataBindings.Add("TEXT", bnContato, "dtcadastro_contato");

                Cidade Cid = new Cidade();
                dsCidade.Tables.Add(Cid.Listar());
                cbxCidade.DataSource = dsCidade.Tables["Cidade"];

                cbxCidade.ValueMember = "id_cidade";

                cbxCidade.DataBindings.Add("SelectedValue", bnContato, "cidade_id_cidade");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btNovo_Click(object sender, EventArgs e)
        {
            if (tbDados.SelectedIndex == 0)
            {
                tbDados.SelectTab(1);
            }
            bnContato.AddNew();
            txtID.Enabled = false;
            txtNome.Enabled = true;
            cbxCidade.Enabled = true;
            cbxCidade.SelectedIndex = 0;
            txtNome.Focus();
            btnSalvar.Enabled = true;
            btnAlterar.Enabled = false;

            btnNovo.Enabled = false;
            btnExcluir.Enabled = false;
            btnCancelar.Enabled = true;
            bInclusao = true;
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            if (txtNome.Text == "")
            {
                MessageBox.Show("Nome inválido!");
            }
            else if (txtEnd.Text == "")
            {
                MessageBox.Show("Endereço inválido");
            }
            else if (txtCelular.Text == "")
            {
                MessageBox.Show("Celular inválido");
            }
            else if (txtEmail.Text == "")
            {
                MessageBox.Show("Email inválido");
            }
            else
            {
                Contato RegCid = new Contato();
             //   RegCid.Idcidade = Convert.ToInt16(txtID.Text);
                RegCid.Nomecontato = txtNome.Text;
                RegCid.Endcontato = txtEnd.Text;
                RegCid.Cidadeidcidade = Convert.ToInt32(cbxCidade.SelectedValue.ToString());
                RegCid.Celcontato = txtCelular.Text;
                RegCid.Emailcontato = txtEmail.Text;
                RegCid.Dtcadastrocontato = dtTimePicker.Value;
                if (bInclusao)
                {
                    if (RegCid.Salvar() > 0)
                    {
                        MessageBox.Show("Contato adicionada com sucesso!");
                        btnSalvar.Enabled = false;
                        txtID.Enabled = false;
                        txtNome.Enabled = false;
                        txtEnd.Enabled = false;
                        cbxCidade.Enabled = false;
                        txtCelular.Enabled = false;
                        txtEmail.Enabled = false;
                        dtTimePicker.Enabled = false;
                        btnSalvar.Enabled = false;
                        btnAlterar.Enabled = true;
                        btnNovo.Enabled = true;
                        btnExcluir.Enabled = true;
                        btnCancelar.Enabled = false;
                        bInclusao = false;
                        // recarrega o grid
                        dsContato.Tables.Clear();
                        dsContato.Tables.Add(RegCid.Listar());
                        bnContato.DataSource = dsContato.Tables["Contato"];
                    }
                    else
                    {
                        MessageBox.Show("Erro ao gravar cidade!");
                    }
                }
                else
                {
                    RegCid.Idcontato = Convert.ToInt32( txtID.Text); 
                    if (RegCid.Alterar() > 0)
                    {
                        MessageBox.Show("Contato alterado com sucesso!");

                        txtID.Enabled = false;
                        txtNome.Enabled = false;
                        txtEnd.Enabled = false;
                        cbxCidade.Enabled = false;
                        txtCelular.Enabled = false;
                        txtEmail.Enabled = false;
                        dtTimePicker.Enabled = false;
                        btnSalvar.Enabled = false;
                        btnAlterar.Enabled = true;
                        btnNovo.Enabled = true;
                        btnExcluir.Enabled = true;
                        btnCancelar.Enabled = false;

                        dsContato.Tables.Clear();
                        dsContato.Tables.Add(RegCid.Listar());
                        bnContato.DataSource = dsContato.Tables["Contato"];

                    }

                    else
                    {
                        MessageBox.Show("Erro ao gravar contato!");
                    }
                }
            }
        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
            if (tbDados.SelectedIndex == 0)
            {
                tbDados.SelectTab(1);
            }

            txtID.Enabled = false;
            txtNome.Enabled = true;
            txtEnd.Enabled = true;
            cbxCidade.Enabled = true;
            txtCelular.Enabled = true;
            txtEmail.Enabled = true;
            dtTimePicker.Enabled = true;
            txtNome.Focus();
            btnSalvar.Enabled = true;
            btnAlterar.Enabled = false;
            btnNovo.Enabled = false;
            btnExcluir.Enabled = false;
            btnCancelar.Enabled = true;
            bInclusao = false;
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            if (tbDados.SelectedIndex == 0)
            {
                tbDados.SelectTab(1);
            }
            if (MessageBox.Show("Confirma exclusão?", "Yes or No",
           MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2)
           == DialogResult.Yes)
            {
                Contato RegCid = new Contato();
                RegCid.Idcontato = Convert.ToInt16(txtID.Text);
                if (RegCid.Excluir() > 0)
                {
                    MessageBox.Show("contato excluído com sucesso!");
                    dsContato.Tables.Clear();
                    dsContato.Tables.Add(RegCid.Listar());
                    bnContato.DataSource = dsContato.Tables["Contato"];
                }
                else
                {
                    MessageBox.Show("Erro ao excluir contato!");
                }
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            bnContato.CancelEdit();
            btnSalvar.Enabled = false;
            txtID.Enabled = false;
            txtNome.Enabled = false;
            txtEnd.Enabled = false;
            cbxCidade.Enabled = false;
            txtCelular.Enabled = false;
            txtEmail.Enabled = false;
            dtTimePicker.Enabled = false;
            btnAlterar.Enabled = true;
            btnNovo.Enabled = true;
            btnCancelar.Enabled = false;
            btnExcluir.Enabled = true;
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void txtNome_Validated(object sender, EventArgs e)
        {
        }

        private void txtEnd_Validated(object sender, EventArgs e)
        {
        }

        private void txtCelular_Validated(object sender, EventArgs e)
        {
        }

        private void txtEmail_Validated(object sender, EventArgs e)
        {
        }
    }
}
