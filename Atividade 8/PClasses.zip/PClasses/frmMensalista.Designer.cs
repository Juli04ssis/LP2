﻿
namespace PClasses
{
    partial class frmMensalista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblMatricula = new System.Windows.Forms.Label();
            this.lblNome = new System.Windows.Forms.Label();
            this.lblDt = new System.Windows.Forms.Label();
            this.lblHO = new System.Windows.Forms.Label();
            this.txtMatricula = new System.Windows.Forms.TextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtHomeOffice = new System.Windows.Forms.TextBox();
            this.txtData = new System.Windows.Forms.TextBox();
            this.btInstanciar = new System.Windows.Forms.Button();
            this.btInstanciarParam = new System.Windows.Forms.Button();
            this.gpBoxHomeOffice = new System.Windows.Forms.GroupBox();
            this.rbtnSim = new System.Windows.Forms.RadioButton();
            this.rbtnNao = new System.Windows.Forms.RadioButton();
            this.txtSalarioMensal = new System.Windows.Forms.TextBox();
            this.lblSalario = new System.Windows.Forms.Label();
            this.gpBoxHomeOffice.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblMatricula
            // 
            this.lblMatricula.AutoSize = true;
            this.lblMatricula.Location = new System.Drawing.Point(45, 75);
            this.lblMatricula.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMatricula.Name = "lblMatricula";
            this.lblMatricula.Size = new System.Drawing.Size(78, 24);
            this.lblMatricula.TabIndex = 0;
            this.lblMatricula.Text = "Matrícula";
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(45, 165);
            this.lblNome.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(168, 24);
            this.lblNome.TabIndex = 1;
            this.lblNome.Text = "Nome do Empregado";
            // 
            // lblDt
            // 
            this.lblDt.AutoSize = true;
            this.lblDt.Location = new System.Drawing.Point(45, 357);
            this.lblDt.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDt.Name = "lblDt";
            this.lblDt.Size = new System.Drawing.Size(220, 24);
            this.lblDt.TabIndex = 2;
            this.lblDt.Text = "Data de entrada na empresa";
            this.lblDt.Click += new System.EventHandler(this.lblDt_Click);
            // 
            // lblHO
            // 
            this.lblHO.AutoSize = true;
            this.lblHO.Location = new System.Drawing.Point(45, 258);
            this.lblHO.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblHO.Name = "lblHO";
            this.lblHO.Size = new System.Drawing.Size(103, 24);
            this.lblHO.TabIndex = 3;
            this.lblHO.Text = "Home Office";
            // 
            // txtMatricula
            // 
            this.txtMatricula.Location = new System.Drawing.Point(341, 68);
            this.txtMatricula.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtMatricula.Name = "txtMatricula";
            this.txtMatricula.Size = new System.Drawing.Size(335, 30);
            this.txtMatricula.TabIndex = 4;
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(251, 158);
            this.txtNome.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(425, 30);
            this.txtNome.TabIndex = 5;
            // 
            // txtHomeOffice
            // 
            this.txtHomeOffice.Location = new System.Drawing.Point(341, 254);
            this.txtHomeOffice.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtHomeOffice.Name = "txtHomeOffice";
            this.txtHomeOffice.Size = new System.Drawing.Size(335, 30);
            this.txtHomeOffice.TabIndex = 6;
            // 
            // txtData
            // 
            this.txtData.Location = new System.Drawing.Point(341, 352);
            this.txtData.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtData.Name = "txtData";
            this.txtData.Size = new System.Drawing.Size(335, 30);
            this.txtData.TabIndex = 7;
            // 
            // btInstanciar
            // 
            this.btInstanciar.Location = new System.Drawing.Point(49, 522);
            this.btInstanciar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btInstanciar.Name = "btInstanciar";
            this.btInstanciar.Size = new System.Drawing.Size(296, 122);
            this.btInstanciar.TabIndex = 8;
            this.btInstanciar.Text = "Instanciar Mensalista";
            this.btInstanciar.UseVisualStyleBackColor = true;
            this.btInstanciar.Click += new System.EventHandler(this.btInstanciar_Click);
            // 
            // btInstanciarParam
            // 
            this.btInstanciarParam.Location = new System.Drawing.Point(352, 522);
            this.btInstanciarParam.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btInstanciarParam.Name = "btInstanciarParam";
            this.btInstanciarParam.Size = new System.Drawing.Size(325, 122);
            this.btInstanciarParam.TabIndex = 9;
            this.btInstanciarParam.Text = "Instanciar Mensalista passando parâmetros";
            this.btInstanciarParam.UseVisualStyleBackColor = true;
            // 
            // gpBoxHomeOffice
            // 
            this.gpBoxHomeOffice.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.gpBoxHomeOffice.Controls.Add(this.rbtnNao);
            this.gpBoxHomeOffice.Controls.Add(this.rbtnSim);
            this.gpBoxHomeOffice.Location = new System.Drawing.Point(726, 68);
            this.gpBoxHomeOffice.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.gpBoxHomeOffice.Name = "gpBoxHomeOffice";
            this.gpBoxHomeOffice.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.gpBoxHomeOffice.Size = new System.Drawing.Size(231, 156);
            this.gpBoxHomeOffice.TabIndex = 10;
            this.gpBoxHomeOffice.TabStop = false;
            this.gpBoxHomeOffice.Text = "Trabalha em Home Office";
            // 
            // rbtnSim
            // 
            this.rbtnSim.AutoSize = true;
            this.rbtnSim.Location = new System.Drawing.Point(0, 48);
            this.rbtnSim.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rbtnSim.Name = "rbtnSim";
            this.rbtnSim.Size = new System.Drawing.Size(62, 28);
            this.rbtnSim.TabIndex = 0;
            this.rbtnSim.TabStop = true;
            this.rbtnSim.Text = "SIM";
            this.rbtnSim.UseVisualStyleBackColor = true;
            // 
            // rbtnNao
            // 
            this.rbtnNao.AutoSize = true;
            this.rbtnNao.Location = new System.Drawing.Point(0, 98);
            this.rbtnNao.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rbtnNao.Name = "rbtnNao";
            this.rbtnNao.Size = new System.Drawing.Size(67, 28);
            this.rbtnNao.TabIndex = 1;
            this.rbtnNao.TabStop = true;
            this.rbtnNao.Text = "NÃO";
            this.rbtnNao.UseVisualStyleBackColor = true;
            // 
            // txtSalarioMensal
            // 
            this.txtSalarioMensal.Location = new System.Drawing.Point(341, 450);
            this.txtSalarioMensal.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtSalarioMensal.Name = "txtSalarioMensal";
            this.txtSalarioMensal.Size = new System.Drawing.Size(335, 30);
            this.txtSalarioMensal.TabIndex = 11;
            // 
            // lblSalario
            // 
            this.lblSalario.AutoSize = true;
            this.lblSalario.Location = new System.Drawing.Point(45, 458);
            this.lblSalario.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSalario.Name = "lblSalario";
            this.lblSalario.Size = new System.Drawing.Size(117, 24);
            this.lblSalario.TabIndex = 12;
            this.lblSalario.Text = "Salário Mensal";
            // 
            // frmMensalista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1038, 662);
            this.Controls.Add(this.lblSalario);
            this.Controls.Add(this.txtSalarioMensal);
            this.Controls.Add(this.gpBoxHomeOffice);
            this.Controls.Add(this.btInstanciarParam);
            this.Controls.Add(this.btInstanciar);
            this.Controls.Add(this.txtData);
            this.Controls.Add(this.txtHomeOffice);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.txtMatricula);
            this.Controls.Add(this.lblHO);
            this.Controls.Add(this.lblDt);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.lblMatricula);
            this.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "frmMensalista";
            this.Text = "frmMensalista";
            this.gpBoxHomeOffice.ResumeLayout(false);
            this.gpBoxHomeOffice.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblMatricula;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblDt;
        private System.Windows.Forms.Label lblHO;
        private System.Windows.Forms.TextBox txtMatricula;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtHomeOffice;
        private System.Windows.Forms.TextBox txtData;
        private System.Windows.Forms.Button btInstanciar;
        private System.Windows.Forms.Button btInstanciarParam;
        private System.Windows.Forms.GroupBox gpBoxHomeOffice;
        private System.Windows.Forms.RadioButton rbtnNao;
        private System.Windows.Forms.RadioButton rbtnSim;
        private System.Windows.Forms.TextBox txtSalarioMensal;
        private System.Windows.Forms.Label lblSalario;
    }
}