﻿
namespace PClasses
{
    partial class frmHorista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gpBoxHomeOffice = new System.Windows.Forms.GroupBox();
            this.rbtnNao = new System.Windows.Forms.RadioButton();
            this.rbtnSim = new System.Windows.Forms.RadioButton();
            this.btInstanciar = new System.Windows.Forms.Button();
            this.txtData = new System.Windows.Forms.TextBox();
            this.txtHomeOffice = new System.Windows.Forms.TextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtMatricula = new System.Windows.Forms.TextBox();
            this.lblHO = new System.Windows.Forms.Label();
            this.lblDt = new System.Windows.Forms.Label();
            this.lblNome = new System.Windows.Forms.Label();
            this.lblMatricula = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtSalarioHora = new System.Windows.Forms.TextBox();
            this.lblNumHora = new System.Windows.Forms.Label();
            this.txtNumHora = new System.Windows.Forms.TextBox();
            this.lblDiasFalta = new System.Windows.Forms.Label();
            this.txtDiasFalta = new System.Windows.Forms.TextBox();
            this.gpBoxHomeOffice.SuspendLayout();
            this.SuspendLayout();
            // 
            // gpBoxHomeOffice
            // 
            this.gpBoxHomeOffice.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.gpBoxHomeOffice.Controls.Add(this.rbtnNao);
            this.gpBoxHomeOffice.Controls.Add(this.rbtnSim);
            this.gpBoxHomeOffice.Location = new System.Drawing.Point(725, 88);
            this.gpBoxHomeOffice.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.gpBoxHomeOffice.Name = "gpBoxHomeOffice";
            this.gpBoxHomeOffice.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.gpBoxHomeOffice.Size = new System.Drawing.Size(231, 156);
            this.gpBoxHomeOffice.TabIndex = 21;
            this.gpBoxHomeOffice.TabStop = false;
            this.gpBoxHomeOffice.Text = "Trabalha em Home Office";
            // 
            // rbtnNao
            // 
            this.rbtnNao.AutoSize = true;
            this.rbtnNao.Location = new System.Drawing.Point(0, 98);
            this.rbtnNao.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rbtnNao.Name = "rbtnNao";
            this.rbtnNao.Size = new System.Drawing.Size(67, 28);
            this.rbtnNao.TabIndex = 1;
            this.rbtnNao.TabStop = true;
            this.rbtnNao.Text = "NÃO";
            this.rbtnNao.UseVisualStyleBackColor = true;
            // 
            // rbtnSim
            // 
            this.rbtnSim.AutoSize = true;
            this.rbtnSim.Location = new System.Drawing.Point(0, 48);
            this.rbtnSim.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rbtnSim.Name = "rbtnSim";
            this.rbtnSim.Size = new System.Drawing.Size(62, 28);
            this.rbtnSim.TabIndex = 0;
            this.rbtnSim.TabStop = true;
            this.rbtnSim.Text = "SIM";
            this.rbtnSim.UseVisualStyleBackColor = true;
            // 
            // btInstanciar
            // 
            this.btInstanciar.Location = new System.Drawing.Point(49, 498);
            this.btInstanciar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btInstanciar.Name = "btInstanciar";
            this.btInstanciar.Size = new System.Drawing.Size(629, 122);
            this.btInstanciar.TabIndex = 19;
            this.btInstanciar.Text = "Instanciar Horista";
            this.btInstanciar.UseVisualStyleBackColor = true;
            this.btInstanciar.Click += new System.EventHandler(this.btInstanciar_Click);
            // 
            // txtData
            // 
            this.txtData.Location = new System.Drawing.Point(340, 248);
            this.txtData.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtData.Name = "txtData";
            this.txtData.Size = new System.Drawing.Size(335, 30);
            this.txtData.TabIndex = 18;
            // 
            // txtHomeOffice
            // 
            this.txtHomeOffice.Location = new System.Drawing.Point(340, 186);
            this.txtHomeOffice.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtHomeOffice.Name = "txtHomeOffice";
            this.txtHomeOffice.Size = new System.Drawing.Size(335, 30);
            this.txtHomeOffice.TabIndex = 17;
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(250, 136);
            this.txtNome.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(425, 30);
            this.txtNome.TabIndex = 16;
            // 
            // txtMatricula
            // 
            this.txtMatricula.Location = new System.Drawing.Point(340, 88);
            this.txtMatricula.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtMatricula.Name = "txtMatricula";
            this.txtMatricula.Size = new System.Drawing.Size(335, 30);
            this.txtMatricula.TabIndex = 15;
            // 
            // lblHO
            // 
            this.lblHO.AutoSize = true;
            this.lblHO.Location = new System.Drawing.Point(45, 194);
            this.lblHO.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblHO.Name = "lblHO";
            this.lblHO.Size = new System.Drawing.Size(103, 24);
            this.lblHO.TabIndex = 14;
            this.lblHO.Text = "Home Office";
            // 
            // lblDt
            // 
            this.lblDt.AutoSize = true;
            this.lblDt.Location = new System.Drawing.Point(44, 255);
            this.lblDt.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDt.Name = "lblDt";
            this.lblDt.Size = new System.Drawing.Size(220, 24);
            this.lblDt.TabIndex = 13;
            this.lblDt.Text = "Data de entrada na empresa";
            this.lblDt.Click += new System.EventHandler(this.lblDt_Click);
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(44, 144);
            this.lblNome.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(168, 24);
            this.lblNome.TabIndex = 12;
            this.lblNome.Text = "Nome do Empregado";
            // 
            // lblMatricula
            // 
            this.lblMatricula.AutoSize = true;
            this.lblMatricula.Location = new System.Drawing.Point(44, 96);
            this.lblMatricula.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMatricula.Name = "lblMatricula";
            this.lblMatricula.Size = new System.Drawing.Size(78, 24);
            this.lblMatricula.TabIndex = 11;
            this.lblMatricula.Text = "Matrícula";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(44, 434);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(99, 24);
            this.label1.TabIndex = 22;
            this.label1.Text = "Salário Hora";
            // 
            // txtSalarioHora
            // 
            this.txtSalarioHora.Location = new System.Drawing.Point(340, 426);
            this.txtSalarioHora.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtSalarioHora.Name = "txtSalarioHora";
            this.txtSalarioHora.Size = new System.Drawing.Size(335, 30);
            this.txtSalarioHora.TabIndex = 23;
            // 
            // lblNumHora
            // 
            this.lblNumHora.AutoSize = true;
            this.lblNumHora.Location = new System.Drawing.Point(44, 312);
            this.lblNumHora.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNumHora.Name = "lblNumHora";
            this.lblNumHora.Size = new System.Drawing.Size(137, 24);
            this.lblNumHora.TabIndex = 24;
            this.lblNumHora.Text = "Número de horas";
            // 
            // txtNumHora
            // 
            this.txtNumHora.Location = new System.Drawing.Point(340, 304);
            this.txtNumHora.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtNumHora.Name = "txtNumHora";
            this.txtNumHora.Size = new System.Drawing.Size(335, 30);
            this.txtNumHora.TabIndex = 25;
            // 
            // lblDiasFalta
            // 
            this.lblDiasFalta.AutoSize = true;
            this.lblDiasFalta.Location = new System.Drawing.Point(44, 374);
            this.lblDiasFalta.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDiasFalta.Name = "lblDiasFalta";
            this.lblDiasFalta.Size = new System.Drawing.Size(106, 24);
            this.lblDiasFalta.TabIndex = 26;
            this.lblDiasFalta.Text = "Dias de Falta";
            // 
            // txtDiasFalta
            // 
            this.txtDiasFalta.Location = new System.Drawing.Point(340, 366);
            this.txtDiasFalta.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtDiasFalta.Name = "txtDiasFalta";
            this.txtDiasFalta.Size = new System.Drawing.Size(335, 30);
            this.txtDiasFalta.TabIndex = 27;
            // 
            // frmHorista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1000, 646);
            this.Controls.Add(this.txtDiasFalta);
            this.Controls.Add(this.lblDiasFalta);
            this.Controls.Add(this.txtNumHora);
            this.Controls.Add(this.lblNumHora);
            this.Controls.Add(this.txtSalarioHora);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.gpBoxHomeOffice);
            this.Controls.Add(this.btInstanciar);
            this.Controls.Add(this.txtData);
            this.Controls.Add(this.txtHomeOffice);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.txtMatricula);
            this.Controls.Add(this.lblHO);
            this.Controls.Add(this.lblDt);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.lblMatricula);
            this.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "frmHorista";
            this.Text = "frmHorista";
            this.gpBoxHomeOffice.ResumeLayout(false);
            this.gpBoxHomeOffice.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox gpBoxHomeOffice;
        private System.Windows.Forms.RadioButton rbtnNao;
        private System.Windows.Forms.RadioButton rbtnSim;
        private System.Windows.Forms.Button btInstanciar;
        private System.Windows.Forms.TextBox txtData;
        private System.Windows.Forms.TextBox txtHomeOffice;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtMatricula;
        private System.Windows.Forms.Label lblHO;
        private System.Windows.Forms.Label lblDt;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblMatricula;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtSalarioHora;
        private System.Windows.Forms.Label lblNumHora;
        private System.Windows.Forms.TextBox txtNumHora;
        private System.Windows.Forms.Label lblDiasFalta;
        private System.Windows.Forms.TextBox txtDiasFalta;
    }
}