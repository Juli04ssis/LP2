﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace Aula_Prática._9
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnInverseFor_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";
            string saida = "";

            for (var i = 0; i < 20; i++)
            {
                auxiliar = Interaction.InputBox("Digite um numero", "Entrada de Dados");

                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Número Inválido");
                    i--;
                }

                else
                {
                    saida = vetor[i].ToString() + "\n" + saida;
                }

                MessageBox.Show(saida);

            }
        }

        private void btnInverterReverse_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";

            for (var i = 0; i < 20; i++)
            {
                auxiliar = Interaction.InputBox("Digite um numero", "Entrada de Dados");

                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Número Inválido");
                    i--;
                }
            }

                Array.Reverse(vetor);

            foreach (var i in vetor)
                auxiliar += "\n" + i.ToString();

            MessageBox.Show(auxiliar); 
        }

        private void btnMercadorias_Click(object sender, EventArgs e)
        {
            string[] mercadorias = new string [10];
            int[] qtdMercadoria = new int [10];
            double[] precos = new double[10];
            int qtd = 0;
            double valor = 0;
            double valorTotal = 0;
            string produtos = "";

            for (int i = 0; i < 10; i++)
            {
                mercadorias[i] = Interaction.InputBox("Digite a mercadoria: ", "Entrada de Mercadorias");

                if (int.TryParse(Interaction.InputBox("Digite a quantidade de " + mercadorias[i] , "Entrada de Quantidade"), out qtd))
                    qtdMercadoria[i] = qtd;

                else
                    MessageBox.Show("Digite uma quantidade válida!");

                if (double.TryParse(Interaction.InputBox("Digite o valor(R$) de " + mercadorias[i], "Entrada de Valor R$"), out valor))
                    precos[i] = valor;

                else
                    MessageBox.Show("Digite um valor válido!");

                valorTotal += valorTotal + (precos[i] * qtdMercadoria[i]);

                produtos = mercadorias[i] + " | Quantidade: " + qtdMercadoria[i] + " | Preço unitário " + precos[i].ToString("C") + "\n" + produtos;

                MessageBox.Show(produtos);
            }

            MessageBox.Show("O faturamento mensal é: " + valorTotal.ToString("C"));
        }

        private void btnVariavelTotal_Click(object sender, EventArgs e)
        {
            string[] Alunos = { "Viviane", "André", "Hélio", "Denise", "Junior", "Leonardo", "Jose", "Nelma", "Tobby" };

            string listaNomes = "Viviane" + "\n" + "André" + "\n" + "Hélio" + "\n" + "Denise" + "\n" + "Junior" + "\n" + "Leonardo" + "\n" + "Jose" + "\n" + "Nelma" + "\n" + "Tobby";

            Int32 I, Total = 0;
            Int32 N = Alunos.Length;

            for (I = 0; I < N - 1; I++)
            {
                Total += Alunos[I].Length;
            }

            MessageBox.Show(listaNomes);

            MessageBox.Show("O valor da variável total é: " + Total.ToString());
        }

        private void btnArrayList_Click(object sender, EventArgs e)
        {
            ArrayList nomes = new ArrayList();

            string listaAlunos = "";
            string alunoRemovido = "Otávio";

            nomes.Add("Ana");
            nomes.Add("André");
            nomes.Add("Débora");
            nomes.Add("Fátima");
            nomes.Add("João");
            nomes.Add("Janete");
            nomes.Add("Otávio");
            nomes.Add("Marcelo");
            nomes.Add("Pedro");
            nomes.Add("Thais");

            for (int i = nomes.Count - 1; i >= 0; i--)
            {
                if (nomes[i].ToString() == alunoRemovido)
                    nomes.RemoveAt(i);
            }

            listaAlunos = string.Join("\n", nomes.ToArray());

            MessageBox.Show(listaAlunos);
        }

        private void btnMédia_Click(object sender, EventArgs e)
        {
            double[ , ] notaAluno = new double[20, 3];
            double[] media = new double[20];
            double nota;

            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    if (double.TryParse(Interaction.InputBox("Digite a nota " + (j + 1) + " do Aluno " + (i + 1), "Média Final"), out nota))
                    {
                        if (nota < 0)
                            MessageBox.Show("Valor Inválido!");

                        else if (nota > 10)
                            MessageBox.Show("Valor Inválido!");
                            
                        else
                            notaAluno[i, j] = nota;
                    }
                    else
                        MessageBox.Show("Insira um valor válido.");

                    media[i] += notaAluno[i, j];
                }
                media[i] = media[i] / 3;

                string mensagem = "A Média Final do Aluno " + (i + 1) + " é: " + media[i].ToString("F1");

                MessageBox.Show(mensagem);

                if (media[i] >= 6)
                    MessageBox.Show("Aluno " + (i + 1) + " está Aprovado!");

                else if (media[i] < 5)
                    MessageBox.Show("Aluno " + (i + 1) + " está Reprovado!");

                else 
                    MessageBox.Show("Aluno " + (i + 1) + " está em Recuperação.");

            }
        }

        private void btnEntradaNomes_Click(object sender, EventArgs e)
        {
            frmExercicio6 Form6 = new frmExercicio6();
            Form6.WindowState = FormWindowState.Normal;
            Form6.Show();
        }
    }
}
