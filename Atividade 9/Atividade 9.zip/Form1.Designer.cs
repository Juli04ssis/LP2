﻿
namespace Aula_Prática._9
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnInverseFor = new System.Windows.Forms.Button();
            this.btnInverterReverse = new System.Windows.Forms.Button();
            this.btnMercadorias = new System.Windows.Forms.Button();
            this.btnVariavelTotal = new System.Windows.Forms.Button();
            this.btnArrayList = new System.Windows.Forms.Button();
            this.btnMédia = new System.Windows.Forms.Button();
            this.btnEntradaNomes = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnInverseFor
            // 
            this.btnInverseFor.Location = new System.Drawing.Point(12, 12);
            this.btnInverseFor.Name = "btnInverseFor";
            this.btnInverseFor.Size = new System.Drawing.Size(121, 103);
            this.btnInverseFor.TabIndex = 0;
            this.btnInverseFor.Text = "Ex. 1 - Ler 20 números e inverter com for";
            this.btnInverseFor.UseVisualStyleBackColor = true;
            this.btnInverseFor.Click += new System.EventHandler(this.btnInverseFor_Click);
            // 
            // btnInverterReverse
            // 
            this.btnInverterReverse.Location = new System.Drawing.Point(139, 12);
            this.btnInverterReverse.Name = "btnInverterReverse";
            this.btnInverterReverse.Size = new System.Drawing.Size(121, 103);
            this.btnInverterReverse.TabIndex = 1;
            this.btnInverterReverse.Text = "Ex. 1 - Ler 20 números e inverter (Reverse)";
            this.btnInverterReverse.UseVisualStyleBackColor = true;
            this.btnInverterReverse.Click += new System.EventHandler(this.btnInverterReverse_Click);
            // 
            // btnMercadorias
            // 
            this.btnMercadorias.Location = new System.Drawing.Point(266, 12);
            this.btnMercadorias.Name = "btnMercadorias";
            this.btnMercadorias.Size = new System.Drawing.Size(121, 103);
            this.btnMercadorias.TabIndex = 2;
            this.btnMercadorias.Text = "Ex. 2 - Ler Quant. e Preço Mercadorias";
            this.btnMercadorias.UseVisualStyleBackColor = true;
            this.btnMercadorias.Click += new System.EventHandler(this.btnMercadorias_Click);
            // 
            // btnVariavelTotal
            // 
            this.btnVariavelTotal.Location = new System.Drawing.Point(12, 121);
            this.btnVariavelTotal.Name = "btnVariavelTotal";
            this.btnVariavelTotal.Size = new System.Drawing.Size(121, 103);
            this.btnVariavelTotal.TabIndex = 3;
            this.btnVariavelTotal.Text = "Ex. 3 - Variável Total";
            this.btnVariavelTotal.UseVisualStyleBackColor = true;
            this.btnVariavelTotal.Click += new System.EventHandler(this.btnVariavelTotal_Click);
            // 
            // btnArrayList
            // 
            this.btnArrayList.Location = new System.Drawing.Point(139, 121);
            this.btnArrayList.Name = "btnArrayList";
            this.btnArrayList.Size = new System.Drawing.Size(121, 103);
            this.btnArrayList.TabIndex = 4;
            this.btnArrayList.Text = "Ex. 4 - ArrayList";
            this.btnArrayList.UseVisualStyleBackColor = true;
            this.btnArrayList.Click += new System.EventHandler(this.btnArrayList_Click);
            // 
            // btnMédia
            // 
            this.btnMédia.Location = new System.Drawing.Point(266, 121);
            this.btnMédia.Name = "btnMédia";
            this.btnMédia.Size = new System.Drawing.Size(121, 103);
            this.btnMédia.TabIndex = 5;
            this.btnMédia.Text = "Ex. 5 - Média Alunos";
            this.btnMédia.UseVisualStyleBackColor = true;
            this.btnMédia.Click += new System.EventHandler(this.btnMédia_Click);
            // 
            // btnEntradaNomes
            // 
            this.btnEntradaNomes.Location = new System.Drawing.Point(139, 230);
            this.btnEntradaNomes.Name = "btnEntradaNomes";
            this.btnEntradaNomes.Size = new System.Drawing.Size(121, 103);
            this.btnEntradaNomes.TabIndex = 6;
            this.btnEntradaNomes.Text = "Ex. 6 - Entrada Nomes";
            this.btnEntradaNomes.UseVisualStyleBackColor = true;
            this.btnEntradaNomes.Click += new System.EventHandler(this.btnEntradaNomes_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(400, 350);
            this.Controls.Add(this.btnEntradaNomes);
            this.Controls.Add(this.btnMédia);
            this.Controls.Add(this.btnArrayList);
            this.Controls.Add(this.btnVariavelTotal);
            this.Controls.Add(this.btnMercadorias);
            this.Controls.Add(this.btnInverterReverse);
            this.Controls.Add(this.btnInverseFor);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnInverseFor;
        private System.Windows.Forms.Button btnInverterReverse;
        private System.Windows.Forms.Button btnMercadorias;
        private System.Windows.Forms.Button btnVariavelTotal;
        private System.Windows.Forms.Button btnArrayList;
        private System.Windows.Forms.Button btnMédia;
        private System.Windows.Forms.Button btnEntradaNomes;
    }
}

