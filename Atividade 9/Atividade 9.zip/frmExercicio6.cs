﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace Aula_Prática._9
{
    public partial class frmExercicio6 : Form
    {
        public frmExercicio6()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            int[] z = new int[1];
            int y = 0;
            string RA = "";

            for (int i = 0; i < 1; i++)
            {
                RA = Interaction.InputBox("Digite o último dígito do seu RA: ", "Entrada de Dados");
                if (int.TryParse(RA, out z[i]))
                    z[i] = Convert.ToInt32(RA);
                else
                    MessageBox.Show("Valor Inválido!");
             
                if (z[i] == 0)
                    y = 10;
                else
                    y = z[i];
            }

            string[] nomes = new string[y];
            string[] nomesOutWhtSpc = new string[20];
            string nome;
            int tamanhoOutWhtSpc = 0;
            int x = 0;

            foreach (var i in nomes)
            {
                nomes[x] = Interaction.InputBox("Digite seu nome completo: ", "Entrada de dados");
                nome = nomes[x];
                nomesOutWhtSpc[x] = nome.Replace(" ", "");

                tamanhoOutWhtSpc = nomesOutWhtSpc[x].Length;

                lstBoxNomes.Items.Add("O nome: " + nomes[x] + " tem\n " + tamanhoOutWhtSpc + " caracteres");
            }
        }
    }
}
