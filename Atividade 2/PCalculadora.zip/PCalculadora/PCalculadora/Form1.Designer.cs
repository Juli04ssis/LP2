﻿
namespace PCalculadora
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl1 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtN1 = new System.Windows.Forms.TextBox();
            this.txtN2 = new System.Windows.Forms.TextBox();
            this.txtResult = new System.Windows.Forms.TextBox();
            this.btPls = new System.Windows.Forms.Button();
            this.btTimes = new System.Windows.Forms.Button();
            this.btLess = new System.Windows.Forms.Button();
            this.btDiv = new System.Windows.Forms.Button();
            this.btCls = new System.Windows.Forms.Button();
            this.btOut = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.Font = new System.Drawing.Font("Arial Narrow", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1.Location = new System.Drawing.Point(35, 86);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(118, 33);
            this.lbl1.TabIndex = 0;
            this.lbl1.Text = "Número 1";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Narrow", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(35, 193);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(118, 33);
            this.label1.TabIndex = 1;
            this.label1.Text = "Número 2";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Narrow", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(35, 292);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(117, 33);
            this.label2.TabIndex = 2;
            this.label2.Text = "Resultado";
            // 
            // txtN1
            // 
            this.txtN1.Location = new System.Drawing.Point(175, 95);
            this.txtN1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtN1.Name = "txtN1";
            this.txtN1.Size = new System.Drawing.Size(256, 22);
            this.txtN1.TabIndex = 3;
            this.txtN1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtN1_KeyPress);
            // 
            // txtN2
            // 
            this.txtN2.Location = new System.Drawing.Point(175, 202);
            this.txtN2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtN2.Name = "txtN2";
            this.txtN2.Size = new System.Drawing.Size(256, 22);
            this.txtN2.TabIndex = 4;
            this.txtN2.TextChanged += new System.EventHandler(this.txtN2_TextChanged);
            this.txtN2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtN2_KeyPress);
            // 
            // txtResult
            // 
            this.txtResult.Location = new System.Drawing.Point(175, 302);
            this.txtResult.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtResult.Name = "txtResult";
            this.txtResult.ReadOnly = true;
            this.txtResult.Size = new System.Drawing.Size(256, 22);
            this.txtResult.TabIndex = 5;
            this.txtResult.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtResult_KeyPress);
            // 
            // btPls
            // 
            this.btPls.Font = new System.Drawing.Font("Arial Narrow", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btPls.Location = new System.Drawing.Point(40, 358);
            this.btPls.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btPls.Name = "btPls";
            this.btPls.Size = new System.Drawing.Size(80, 82);
            this.btPls.TabIndex = 6;
            this.btPls.Text = "+";
            this.btPls.UseVisualStyleBackColor = true;
            this.btPls.Click += new System.EventHandler(this.btPls_Click);
            // 
            // btTimes
            // 
            this.btTimes.Font = new System.Drawing.Font("Arial Narrow", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btTimes.Location = new System.Drawing.Point(125, 358);
            this.btTimes.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btTimes.Name = "btTimes";
            this.btTimes.Size = new System.Drawing.Size(80, 82);
            this.btTimes.TabIndex = 7;
            this.btTimes.Text = "x";
            this.btTimes.UseVisualStyleBackColor = true;
            this.btTimes.Click += new System.EventHandler(this.btTimes_Click);
            // 
            // btLess
            // 
            this.btLess.Font = new System.Drawing.Font("Arial Narrow", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btLess.Location = new System.Drawing.Point(40, 446);
            this.btLess.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btLess.Name = "btLess";
            this.btLess.Size = new System.Drawing.Size(80, 82);
            this.btLess.TabIndex = 8;
            this.btLess.Text = "-";
            this.btLess.UseVisualStyleBackColor = true;
            this.btLess.Click += new System.EventHandler(this.btLess_Click);
            // 
            // btDiv
            // 
            this.btDiv.Font = new System.Drawing.Font("Arial Narrow", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btDiv.Location = new System.Drawing.Point(125, 446);
            this.btDiv.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btDiv.Name = "btDiv";
            this.btDiv.Size = new System.Drawing.Size(80, 82);
            this.btDiv.TabIndex = 9;
            this.btDiv.Text = "/";
            this.btDiv.UseVisualStyleBackColor = true;
            this.btDiv.Click += new System.EventHandler(this.btDiv_Click);
            // 
            // btCls
            // 
            this.btCls.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btCls.Location = new System.Drawing.Point(287, 358);
            this.btCls.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btCls.Name = "btCls";
            this.btCls.Size = new System.Drawing.Size(144, 82);
            this.btCls.TabIndex = 10;
            this.btCls.Text = "LIMPAR";
            this.btCls.UseVisualStyleBackColor = true;
            this.btCls.Click += new System.EventHandler(this.btCls_Click);
            // 
            // btOut
            // 
            this.btOut.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btOut.Location = new System.Drawing.Point(287, 446);
            this.btOut.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btOut.Name = "btOut";
            this.btOut.Size = new System.Drawing.Size(144, 82);
            this.btOut.TabIndex = 11;
            this.btOut.Text = "SAIR";
            this.btOut.UseVisualStyleBackColor = true;
            this.btOut.Click += new System.EventHandler(this.btOut_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(463, 534);
            this.Controls.Add(this.btOut);
            this.Controls.Add(this.btCls);
            this.Controls.Add(this.btDiv);
            this.Controls.Add(this.btLess);
            this.Controls.Add(this.btTimes);
            this.Controls.Add(this.btPls);
            this.Controls.Add(this.txtResult);
            this.Controls.Add(this.txtN2);
            this.Controls.Add(this.txtN1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbl1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtN1;
        private System.Windows.Forms.TextBox txtN2;
        private System.Windows.Forms.TextBox txtResult;
        private System.Windows.Forms.Button btPls;
        private System.Windows.Forms.Button btTimes;
        private System.Windows.Forms.Button btLess;
        private System.Windows.Forms.Button btDiv;
        private System.Windows.Forms.Button btCls;
        private System.Windows.Forms.Button btOut;
    }
}

