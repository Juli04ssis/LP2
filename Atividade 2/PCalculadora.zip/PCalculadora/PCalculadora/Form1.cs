﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCalculadora
{
    public partial class Form1 : Form
    {
        double num1, num2, result;

        private void btLess_Click(object sender, EventArgs e)
        {
            if (Double.TryParse(txtN1.Text, out num1) && Double.TryParse(txtN2.Text, out num2))
            {
                result = num1 - num2;

                txtResult.Text = result.ToString();
            }
            else
                MessageBox.Show("Número Inválido!");

        }

        private void btTimes_Click(object sender, EventArgs e)
        {
            if (Double.TryParse(txtN1.Text, out num1) && Double.TryParse(txtN2.Text, out num2))
            {
                result = num1 * num2;

                txtResult.Text = result.ToString();
            }
            else
                MessageBox.Show("Número Inválido!");
        }

        private void btDiv_Click(object sender, EventArgs e)
        {
            if (Double.TryParse(txtN1.Text, out num1) && Double.TryParse(txtN2.Text, out num2))
            {
                result = num1 / num2;

                txtResult.Text = result.ToString();
            }
            else
                MessageBox.Show("Número Inválido!");
        }

        private void btCls_Click(object sender, EventArgs e)
        {
            txtN1.Clear();
            txtN2.Clear();
            txtResult.Clear();
        }

        private void btOut_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void txtN2_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtN1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)(13))
            {
                SendKeys.Send("{TAB}");
                e.Handled = true;
            }
        }

        private void txtN2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)(13))
            {
                SendKeys.Send("{TAB}");
                e.Handled = true;
            }
        }

        private void txtResult_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)(13))
            {
                SendKeys.Send("{TAB}");
                e.Handled = true;
            }
        }

        public Form1()
        {

            InitializeComponent();
        }

        private void btPls_Click(object sender, EventArgs e)
        {
            if(Double.TryParse(txtN1.Text, out num1) && Double.TryParse(txtN2.Text, out num2))
            {
                result = num1 + num2;

                txtResult.Text = result.ToString();
            }
            else
                MessageBox.Show("Número Inválido!");
        }
    }
}
