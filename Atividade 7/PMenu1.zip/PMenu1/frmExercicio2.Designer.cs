﻿
namespace PMenu1
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblPalavra1 = new System.Windows.Forms.Label();
            this.lblPalavra2 = new System.Windows.Forms.Label();
            this.txtPalavra1 = new System.Windows.Forms.TextBox();
            this.txtPalavra2 = new System.Windows.Forms.TextBox();
            this.btVerify = new System.Windows.Forms.Button();
            this.btInsert1to2 = new System.Windows.Forms.Button();
            this.btInsertSpace = new System.Windows.Forms.Button();
            this.btClear = new System.Windows.Forms.Button();
            this.btClose = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblPalavra1
            // 
            this.lblPalavra1.AutoSize = true;
            this.lblPalavra1.Location = new System.Drawing.Point(41, 76);
            this.lblPalavra1.Name = "lblPalavra1";
            this.lblPalavra1.Size = new System.Drawing.Size(64, 17);
            this.lblPalavra1.TabIndex = 0;
            this.lblPalavra1.Text = "Palavra1";
            // 
            // lblPalavra2
            // 
            this.lblPalavra2.AutoSize = true;
            this.lblPalavra2.Location = new System.Drawing.Point(41, 172);
            this.lblPalavra2.Name = "lblPalavra2";
            this.lblPalavra2.Size = new System.Drawing.Size(64, 17);
            this.lblPalavra2.TabIndex = 1;
            this.lblPalavra2.Text = "Palavra2";
            // 
            // txtPalavra1
            // 
            this.txtPalavra1.Location = new System.Drawing.Point(120, 73);
            this.txtPalavra1.Name = "txtPalavra1";
            this.txtPalavra1.Size = new System.Drawing.Size(289, 22);
            this.txtPalavra1.TabIndex = 2;
            // 
            // txtPalavra2
            // 
            this.txtPalavra2.Location = new System.Drawing.Point(120, 169);
            this.txtPalavra2.Name = "txtPalavra2";
            this.txtPalavra2.Size = new System.Drawing.Size(289, 22);
            this.txtPalavra2.TabIndex = 3;
            // 
            // btVerify
            // 
            this.btVerify.Location = new System.Drawing.Point(44, 240);
            this.btVerify.Name = "btVerify";
            this.btVerify.Size = new System.Drawing.Size(117, 107);
            this.btVerify.TabIndex = 4;
            this.btVerify.Text = "Verificar se são iguais";
            this.btVerify.UseVisualStyleBackColor = true;
            this.btVerify.Click += new System.EventHandler(this.btVerify_Click);
            // 
            // btInsert1to2
            // 
            this.btInsert1to2.Location = new System.Drawing.Point(183, 240);
            this.btInsert1to2.Name = "btInsert1to2";
            this.btInsert1to2.Size = new System.Drawing.Size(117, 107);
            this.btInsert1to2.TabIndex = 5;
            this.btInsert1to2.Text = "Insere 1ª na 2ª";
            this.btInsert1to2.UseVisualStyleBackColor = true;
            this.btInsert1to2.Click += new System.EventHandler(this.btInsert1to2_Click);
            // 
            // btInsertSpace
            // 
            this.btInsertSpace.Location = new System.Drawing.Point(321, 240);
            this.btInsertSpace.Name = "btInsertSpace";
            this.btInsertSpace.Size = new System.Drawing.Size(117, 107);
            this.btInsertSpace.TabIndex = 6;
            this.btInsertSpace.Text = "Insere \" \" no meio";
            this.btInsertSpace.UseVisualStyleBackColor = true;
            this.btInsertSpace.Click += new System.EventHandler(this.btInsertSpace_Click);
            // 
            // btClear
            // 
            this.btClear.Location = new System.Drawing.Point(44, 364);
            this.btClear.Name = "btClear";
            this.btClear.Size = new System.Drawing.Size(194, 47);
            this.btClear.TabIndex = 7;
            this.btClear.Text = "Limpar\r\n";
            this.btClear.UseVisualStyleBackColor = true;
            this.btClear.Click += new System.EventHandler(this.btClear_Click);
            // 
            // btClose
            // 
            this.btClose.Location = new System.Drawing.Point(244, 364);
            this.btClose.Name = "btClose";
            this.btClose.Size = new System.Drawing.Size(194, 47);
            this.btClose.TabIndex = 8;
            this.btClose.Text = "Fechar";
            this.btClose.UseVisualStyleBackColor = true;
            this.btClose.Click += new System.EventHandler(this.btClose_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(463, 421);
            this.Controls.Add(this.btClose);
            this.Controls.Add(this.btClear);
            this.Controls.Add(this.btInsertSpace);
            this.Controls.Add(this.btInsert1to2);
            this.Controls.Add(this.btVerify);
            this.Controls.Add(this.txtPalavra2);
            this.Controls.Add(this.txtPalavra1);
            this.Controls.Add(this.lblPalavra2);
            this.Controls.Add(this.lblPalavra1);
            this.Name = "Form2";
            this.Text = "Form2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblPalavra1;
        private System.Windows.Forms.Label lblPalavra2;
        private System.Windows.Forms.TextBox txtPalavra1;
        private System.Windows.Forms.TextBox txtPalavra2;
        private System.Windows.Forms.Button btVerify;
        private System.Windows.Forms.Button btInsert1to2;
        private System.Windows.Forms.Button btInsertSpace;
        private System.Windows.Forms.Button btClear;
        private System.Windows.Forms.Button btClose;
    }
}