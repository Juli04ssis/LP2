﻿
namespace PMenu1
{
    partial class frmExercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblPalavra1 = new System.Windows.Forms.Label();
            this.lblPalavra2 = new System.Windows.Forms.Label();
            this.txtpalavra1 = new System.Windows.Forms.TextBox();
            this.txtPalavra2 = new System.Windows.Forms.TextBox();
            this.btVerify = new System.Windows.Forms.Button();
            this.btRemove = new System.Windows.Forms.Button();
            this.btInvert = new System.Windows.Forms.Button();
            this.btClean = new System.Windows.Forms.Button();
            this.btClose = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblPalavra1
            // 
            this.lblPalavra1.AutoSize = true;
            this.lblPalavra1.Location = new System.Drawing.Point(51, 73);
            this.lblPalavra1.Name = "lblPalavra1";
            this.lblPalavra1.Size = new System.Drawing.Size(68, 17);
            this.lblPalavra1.TabIndex = 0;
            this.lblPalavra1.Text = "Palavra 1";
            // 
            // lblPalavra2
            // 
            this.lblPalavra2.AutoSize = true;
            this.lblPalavra2.Location = new System.Drawing.Point(51, 154);
            this.lblPalavra2.Name = "lblPalavra2";
            this.lblPalavra2.Size = new System.Drawing.Size(68, 17);
            this.lblPalavra2.TabIndex = 1;
            this.lblPalavra2.Text = "Palavra 2";
            // 
            // txtpalavra1
            // 
            this.txtpalavra1.Location = new System.Drawing.Point(136, 70);
            this.txtpalavra1.Name = "txtpalavra1";
            this.txtpalavra1.Size = new System.Drawing.Size(310, 22);
            this.txtpalavra1.TabIndex = 2;
            // 
            // txtPalavra2
            // 
            this.txtPalavra2.Location = new System.Drawing.Point(136, 151);
            this.txtPalavra2.Name = "txtPalavra2";
            this.txtPalavra2.Size = new System.Drawing.Size(310, 22);
            this.txtPalavra2.TabIndex = 4;
            // 
            // btVerify
            // 
            this.btVerify.Location = new System.Drawing.Point(54, 241);
            this.btVerify.Name = "btVerify";
            this.btVerify.Size = new System.Drawing.Size(123, 102);
            this.btVerify.TabIndex = 5;
            this.btVerify.Text = "Verificar se são iguais";
            this.btVerify.UseVisualStyleBackColor = true;
            this.btVerify.Click += new System.EventHandler(this.btVerify_Click);
            // 
            // btRemove
            // 
            this.btRemove.Location = new System.Drawing.Point(207, 241);
            this.btRemove.Name = "btRemove";
            this.btRemove.Size = new System.Drawing.Size(123, 102);
            this.btRemove.TabIndex = 6;
            this.btRemove.Text = "Remove ocorrências 1º no 2º(Replace)";
            this.btRemove.UseVisualStyleBackColor = true;
            this.btRemove.Click += new System.EventHandler(this.btRemove_Click);
            // 
            // btInvert
            // 
            this.btInvert.Location = new System.Drawing.Point(359, 241);
            this.btInvert.Name = "btInvert";
            this.btInvert.Size = new System.Drawing.Size(123, 102);
            this.btInvert.TabIndex = 7;
            this.btInvert.Text = "Inverte palavra 1";
            this.btInvert.UseVisualStyleBackColor = true;
            this.btInvert.Click += new System.EventHandler(this.btInvert_Click);
            // 
            // btClean
            // 
            this.btClean.Location = new System.Drawing.Point(54, 366);
            this.btClean.Name = "btClean";
            this.btClean.Size = new System.Drawing.Size(212, 53);
            this.btClean.TabIndex = 8;
            this.btClean.Text = "Limpar";
            this.btClean.UseVisualStyleBackColor = true;
            this.btClean.Click += new System.EventHandler(this.btClean_Click);
            // 
            // btClose
            // 
            this.btClose.Location = new System.Drawing.Point(270, 366);
            this.btClose.Name = "btClose";
            this.btClose.Size = new System.Drawing.Size(212, 53);
            this.btClose.TabIndex = 9;
            this.btClose.Text = "Fechar";
            this.btClose.UseVisualStyleBackColor = true;
            this.btClose.Click += new System.EventHandler(this.btClose_Click);
            // 
            // frmExercicio3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(525, 431);
            this.Controls.Add(this.btClose);
            this.Controls.Add(this.btClean);
            this.Controls.Add(this.btInvert);
            this.Controls.Add(this.btRemove);
            this.Controls.Add(this.btVerify);
            this.Controls.Add(this.txtPalavra2);
            this.Controls.Add(this.txtpalavra1);
            this.Controls.Add(this.lblPalavra2);
            this.Controls.Add(this.lblPalavra1);
            this.Name = "frmExercicio3";
            this.Text = "frmExercicio3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblPalavra1;
        private System.Windows.Forms.Label lblPalavra2;
        private System.Windows.Forms.TextBox txtpalavra1;
        private System.Windows.Forms.TextBox txtPalavra2;
        private System.Windows.Forms.Button btVerify;
        private System.Windows.Forms.Button btRemove;
        private System.Windows.Forms.Button btInvert;
        private System.Windows.Forms.Button btClean;
        private System.Windows.Forms.Button btClose;
    }
}