﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMenu1
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void btClean_Click(object sender, EventArgs e)
        {
            txtpalavra1.Clear();
            txtPalavra2.Clear();
        }

        private void btClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btVerify_Click(object sender, EventArgs e)
        {
            int posicao = txtPalavra2.Text.IndexOf(txtpalavra1.Text);

            while (posicao >= 0)
            {
                txtPalavra2.Text = txtPalavra2.Text.Substring(0, posicao) +
                txtPalavra2.Text.Substring(txtpalavra1.Text.Length + posicao, txtPalavra2.Text.Length - posicao - txtPalavra1.Text.Length);

                posicao = txtPalavra2.Text.IndexOf(txtpalavra1.Text);
            }
        }

        private void btRemove_Click(object sender, EventArgs e)
        {
            txtPalavra2.Text = txtPalavra2.Text.Replace(txtpalavra1.Text, "");
        }

        private void btInvert_Click(object sender, EventArgs e)
        {
            char[] meuArray = txtpalavra1.Text.ToCharArray();

            Array.Reverse(meuArray);

            foreach (var c in meuArray)
                txtPalavra2.Text += c;

            MessageBox.Show(txtPalavra2.Text);
        }
    }
}
