﻿
namespace PMenu1
{
    partial class frmExercicio5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtMin = new System.Windows.Forms.TextBox();
            this.txtMax = new System.Windows.Forms.TextBox();
            this.lblNum1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btSortear = new System.Windows.Forms.Button();
            this.btClean = new System.Windows.Forms.Button();
            this.btClose = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtMin
            // 
            this.txtMin.Location = new System.Drawing.Point(123, 54);
            this.txtMin.Name = "txtMin";
            this.txtMin.Size = new System.Drawing.Size(263, 22);
            this.txtMin.TabIndex = 0;
            // 
            // txtMax
            // 
            this.txtMax.Location = new System.Drawing.Point(123, 146);
            this.txtMax.Name = "txtMax";
            this.txtMax.Size = new System.Drawing.Size(263, 22);
            this.txtMax.TabIndex = 1;
            // 
            // lblNum1
            // 
            this.lblNum1.AutoSize = true;
            this.lblNum1.Location = new System.Drawing.Point(20, 57);
            this.lblNum1.Name = "lblNum1";
            this.lblNum1.Size = new System.Drawing.Size(97, 17);
            this.lblNum1.TabIndex = 2;
            this.lblNum1.Text = "Número Inicial";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(8, 149);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(109, 17);
            this.label2.TabIndex = 3;
            this.label2.Text = "Número Máximo";
            // 
            // btSortear
            // 
            this.btSortear.Location = new System.Drawing.Point(123, 208);
            this.btSortear.Name = "btSortear";
            this.btSortear.Size = new System.Drawing.Size(263, 53);
            this.btSortear.TabIndex = 4;
            this.btSortear.Text = "Sortear";
            this.btSortear.UseVisualStyleBackColor = true;
            this.btSortear.Click += new System.EventHandler(this.btSortear_Click);
            // 
            // btClean
            // 
            this.btClean.Location = new System.Drawing.Point(123, 267);
            this.btClean.Name = "btClean";
            this.btClean.Size = new System.Drawing.Size(263, 53);
            this.btClean.TabIndex = 5;
            this.btClean.Text = "Limpar";
            this.btClean.UseVisualStyleBackColor = true;
            this.btClean.Click += new System.EventHandler(this.btClean_Click);
            // 
            // btClose
            // 
            this.btClose.Location = new System.Drawing.Point(123, 326);
            this.btClose.Name = "btClose";
            this.btClose.Size = new System.Drawing.Size(263, 53);
            this.btClose.TabIndex = 6;
            this.btClose.Text = "Fechar";
            this.btClose.UseVisualStyleBackColor = true;
            this.btClose.Click += new System.EventHandler(this.btClose_Click);
            // 
            // frmExercicio5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(415, 398);
            this.Controls.Add(this.btClose);
            this.Controls.Add(this.btClean);
            this.Controls.Add(this.btSortear);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblNum1);
            this.Controls.Add(this.txtMax);
            this.Controls.Add(this.txtMin);
            this.Name = "frmExercicio5";
            this.Text = "frmExercicio5";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtMin;
        private System.Windows.Forms.TextBox txtMax;
        private System.Windows.Forms.Label lblNum1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btSortear;
        private System.Windows.Forms.Button btClean;
        private System.Windows.Forms.Button btClose;
    }
}