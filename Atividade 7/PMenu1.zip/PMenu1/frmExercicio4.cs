﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMenu1
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btQtdCaracNum_Click(object sender, EventArgs e)
        {
            int contador = 0;
            string texto = rtxtAlfaNum.Text;
            for (int i = 0; i < texto.Length; i++)
            {
                if (Char.IsNumber(texto[i]))
                {
                    contador++;
                }
            }
            MessageBox.Show($"O texto contém {contador} caracteres numéricos.");



        }

        private void btWhiteSpaceFindr_Click(object sender, EventArgs e)
        {
            int posicao = 0;
            string texto = rtxtAlfaNum.Text;
            while (posicao < texto.Length && !Char.IsWhiteSpace(texto[posicao]))
            {
                posicao++;
            }
            if (posicao < texto.Length)
            {
                MessageBox.Show($"O primeiro espaço em branco está na posição {posicao}.");
            }
            else
            {
                MessageBox.Show("Não foi encontrado nenhum espaço em branco.");
            }

        }

        private void btQtdCaracAlfa_Click(object sender, EventArgs e)
        {
            int contador = 0;
            string texto = rtxtAlfaNum.Text;
            foreach (char c in texto)
            {
                if (Char.IsLetter(c))
                {
                    contador++;
                }
            }
            MessageBox.Show($"O texto contém {contador} caracteres alfabéticos.");

        }

        private void btClean_Click(object sender, EventArgs e)
        {
            rtxtAlfaNum.Clear();
        }

        private void btClose_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
