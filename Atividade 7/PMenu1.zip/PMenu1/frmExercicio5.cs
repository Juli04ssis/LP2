﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMenu1
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btSortear_Click(object sender, EventArgs e)
        {
            int numero1 = int.Parse(txtMax.Text);
            int numero2 = int.Parse(txtMin.Text);

            if (numero1 >= numero2)
            {
                MessageBox.Show("O número mínimo deve ser menor do que o número máximo.");
                return;
            }

            Random rnd = new Random();
            int numeroSorteado = rnd.Next(numero1, numero2 + 1);

            MessageBox.Show($"O número sorteado foi: {numeroSorteado}");

        }

        private void btClean_Click(object sender, EventArgs e)
        {
            txtMax.Clear();
            txtMin.Clear();
        }

        private void btClose_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
