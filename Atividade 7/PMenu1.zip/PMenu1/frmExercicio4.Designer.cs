﻿
namespace PMenu1
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btQtdCaracNum = new System.Windows.Forms.Button();
            this.btWhiteSpaceFindr = new System.Windows.Forms.Button();
            this.btQtdCaracAlfa = new System.Windows.Forms.Button();
            this.btClean = new System.Windows.Forms.Button();
            this.btClose = new System.Windows.Forms.Button();
            this.rtxtAlfaNum = new System.Windows.Forms.RichTextBox();
            this.lblText1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btQtdCaracNum
            // 
            this.btQtdCaracNum.Location = new System.Drawing.Point(26, 111);
            this.btQtdCaracNum.Name = "btQtdCaracNum";
            this.btQtdCaracNum.Size = new System.Drawing.Size(111, 108);
            this.btQtdCaracNum.TabIndex = 0;
            this.btQtdCaracNum.Text = "Verificar quantidade de caracteres numéricos";
            this.btQtdCaracNum.UseVisualStyleBackColor = true;
            this.btQtdCaracNum.Click += new System.EventHandler(this.btQtdCaracNum_Click);
            // 
            // btWhiteSpaceFindr
            // 
            this.btWhiteSpaceFindr.Location = new System.Drawing.Point(142, 111);
            this.btWhiteSpaceFindr.Name = "btWhiteSpaceFindr";
            this.btWhiteSpaceFindr.Size = new System.Drawing.Size(108, 108);
            this.btWhiteSpaceFindr.TabIndex = 1;
            this.btWhiteSpaceFindr.Text = "Verificar posição do primeiro espaço em branco";
            this.btWhiteSpaceFindr.UseVisualStyleBackColor = true;
            this.btWhiteSpaceFindr.Click += new System.EventHandler(this.btWhiteSpaceFindr_Click);
            // 
            // btQtdCaracAlfa
            // 
            this.btQtdCaracAlfa.Location = new System.Drawing.Point(256, 111);
            this.btQtdCaracAlfa.Name = "btQtdCaracAlfa";
            this.btQtdCaracAlfa.Size = new System.Drawing.Size(105, 108);
            this.btQtdCaracAlfa.TabIndex = 2;
            this.btQtdCaracAlfa.Text = "Verificar quantidade de caracteres Alfabéticos";
            this.btQtdCaracAlfa.UseVisualStyleBackColor = true;
            this.btQtdCaracAlfa.Click += new System.EventHandler(this.btQtdCaracAlfa_Click);
            // 
            // btClean
            // 
            this.btClean.Location = new System.Drawing.Point(26, 225);
            this.btClean.Name = "btClean";
            this.btClean.Size = new System.Drawing.Size(166, 55);
            this.btClean.TabIndex = 3;
            this.btClean.Text = "Limpar";
            this.btClean.UseVisualStyleBackColor = true;
            this.btClean.Click += new System.EventHandler(this.btClean_Click);
            // 
            // btClose
            // 
            this.btClose.Location = new System.Drawing.Point(195, 225);
            this.btClose.Name = "btClose";
            this.btClose.Size = new System.Drawing.Size(166, 55);
            this.btClose.TabIndex = 4;
            this.btClose.Text = "Sair";
            this.btClose.UseVisualStyleBackColor = true;
            this.btClose.Click += new System.EventHandler(this.btClose_Click);
            // 
            // rtxtAlfaNum
            // 
            this.rtxtAlfaNum.Location = new System.Drawing.Point(25, 47);
            this.rtxtAlfaNum.Name = "rtxtAlfaNum";
            this.rtxtAlfaNum.Size = new System.Drawing.Size(336, 48);
            this.rtxtAlfaNum.TabIndex = 5;
            this.rtxtAlfaNum.Text = "";
            // 
            // lblText1
            // 
            this.lblText1.AutoSize = true;
            this.lblText1.Location = new System.Drawing.Point(22, 27);
            this.lblText1.Name = "lblText1";
            this.lblText1.Size = new System.Drawing.Size(115, 17);
            this.lblText1.TabIndex = 6;
            this.lblText1.Text = "Digite uma frase:";
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(386, 293);
            this.Controls.Add(this.lblText1);
            this.Controls.Add(this.rtxtAlfaNum);
            this.Controls.Add(this.btClose);
            this.Controls.Add(this.btClean);
            this.Controls.Add(this.btQtdCaracAlfa);
            this.Controls.Add(this.btWhiteSpaceFindr);
            this.Controls.Add(this.btQtdCaracNum);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btQtdCaracNum;
        private System.Windows.Forms.Button btWhiteSpaceFindr;
        private System.Windows.Forms.Button btQtdCaracAlfa;
        private System.Windows.Forms.Button btClean;
        private System.Windows.Forms.Button btClose;
        private System.Windows.Forms.RichTextBox rtxtAlfaNum;
        private System.Windows.Forms.Label lblText1;
    }
}